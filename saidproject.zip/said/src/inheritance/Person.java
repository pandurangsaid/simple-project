package inheritance;
 




public class Person {
	String Name;
	  int Age;
	  long Phone;
	 int Age1;
 void getPersonInfo(String name,int age,long phone){

	Name=name;
	Age=age;
	Phone=phone;
	
	
}
 void showPerson() {
	 System.out.println("-------*------");
	 System.out.println("Name--->"+Name);
	 System.out.println("Age--->"+Age);
	 System.out.println("Phone-->"+Phone);
	 
	 
	
	 
	 
 }
 }
