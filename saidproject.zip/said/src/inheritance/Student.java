package inheritance;

public class Student extends Person {
	int Rollno;
	int Age1;
void getStudentInfo(int rollno,int age) {
	Rollno=rollno;
	Age1=age;
	
	
}
void showStudemt() {
	System.out.println("-----*-----");
	System.out.println("Rollno--->"+Rollno);
	System.out.println("Age--->"+Age1);
	
	
}
}
