package inheritance;


import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
	Scanner s1=new Scanner(System.in);
//canner s2=new Scanner(System.in);
	System.out.println("Enter the name-->");
	String Name=s1.next();
	System.out.println("Enter the Age--> ");
	int Age=s1.nextInt();
	System.out.println("Enter the phone--->");
	long Long=s1.nextLong();
	System.out.println("Enter the rollcall");
int rollcal=s1.nextInt();
	Student b1=new Student();
	b1.getPersonInfo(Name, Age, Long);
	b1.getStudentInfo(Age, Age);
	b1.showPerson();
	b1.showStudemt();
	Student b2=new Student();
	b2.getStudentInfo(Age, Age);
	
	
	}
	

}
